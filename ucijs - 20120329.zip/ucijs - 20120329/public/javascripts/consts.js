define({
  START_POS: 'rnbakabnr/9/1c5c1/p1p1p1p1p/9/9/P1P1P1P1P/1C5C1/9/RNBAKABNR w - - 0 1',
  ALL_PIECES: 'rnbakabnrccpppppPPPPPCCRNBAKABNR',
  ALL_PIECETYPES: 'rnbakcpRNBAKCP',
  PIECE_NUM: 32,
  ROW_NUM: 10,
  COL_NUM: 9
});
